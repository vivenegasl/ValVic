/**
 * nav.js
 * Navegación: scroll sticky, menú móvil, smooth scroll.
 */

(function () {
  // ── Sticky nav ────────────────────────────────────────────
  const nav = document.getElementById("nav");
  if (nav) {
    window.addEventListener("scroll", () => {
      nav.classList.toggle("scrolled", window.scrollY > 20);
    });
  }

  // ── Mobile menu ───────────────────────────────────────────
  window.toggleMobile = function () {
    document.getElementById("mobile-nav")?.classList.toggle("open");
  };

  window.closeMobile = function () {
    document.getElementById("mobile-nav")?.classList.remove("open");
  };

  // ── Smooth scroll para links internos ─────────────────────
  document.querySelectorAll('a[href^="#"]').forEach((a) => {
    a.addEventListener("click", (e) => {
      const target = document.querySelector(a.getAttribute("href"));
      if (target) {
        e.preventDefault();
        window.closeMobile();
        target.scrollIntoView({ behavior: "smooth" });
      }
    });
  });

  // ── Cursor glow ───────────────────────────────────────────
  const glow = document.getElementById("cursor-glow");
  if (glow) {
    document.addEventListener("mousemove", (e) => {
      glow.style.left = e.clientX + "px";
      glow.style.top  = e.clientY + "px";
    });
  }
})();
